# 象棋

#### 项目介绍 

    一个网络在线象棋

#### 软件架构

    Spring Boot
    Spring Data Jpa
    JavaMail
    Maven
    lombok
    druid


#### 参与贡献人员

> [张闫](https://gitee.com/bitcod) [周庆凯](#) [邵宇翔](#)