package com.zy.xiangqi.dao;

import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.dao.UserDao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserDaoTest {

    @Autowired
    private UserDao userDao;

    @Test
    public void testFind() {
        User user=userDao.findById(1).get();
        System.out.println(user);
    }
}