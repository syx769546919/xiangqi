package com.zy.xiangqi.utils;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JavaMailTest {

    @Test
    public void testFind() {
        String from="646922470@qq.com";
        String to="819036346@qq.com";
        String subject="网络在线象棋 - 好友邀请";
        String text="您的朋友:xxx 邀请您试玩网络在线象棋游戏!";
        JavaMailSenderUtil.simpleSender(from, to, subject, text);
    }
}