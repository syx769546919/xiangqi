var Login={};

// $.ajax({
//     url:"/user/getRoom",
//     dataType:"json",
//     success:(data)=>{
//         console.info("check room:"+data);
//         Room=data;
//     }
// });
$.ajax({
    url:"/user/json",
    dataType:"json",
    async:false,
    success:(data)=>{
        console.info("check login:");
        console.info(data);
        Login=data;
    }
});
console.info(Login);
Login.getSelf=()=>{
    if(Login.gamerole=="red"){
        return 1;
    }
    return -1;
};

Login.getTargetid=()=>{
    if(Login.gamerole=="red"){
        return Login.room.black;
    }
    return Login.room.red;
};
console.info(Login);