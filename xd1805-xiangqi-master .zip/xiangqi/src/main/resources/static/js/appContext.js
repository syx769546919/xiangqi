/*
    appContext: 用于保存用户在浏览器端的一些缓存等信息
    
*/

var AppContext={};

var websocket = null;

AppContext.connect = (id)=>{
    //判断当前浏览器是否支持WebSocket
    if('WebSocket' in window){
        //var t=$("#txt").val();
        var id=Login.user.id;
        console.info("连接服务器:"+id);
        websocket = new WebSocket("ws://192.168.1.13/websocket/"+id);
    }else{
        alert('Not support websocket');
    }

    //连接发生错误的回调方法
    websocket.onerror = ()=>{
        
    };
    //连接成功建立的回调方法
    websocket.onopen = (event)=>{
        $("#tx").append("连接成功!");
    };

    //接收到消息的回调方法
    websocket.onmessage = (event)=>{
        //接收消息
        //alert(event);
        console.info("event");
        console.info(event);
        var data=event.data;
        console.info(data);
        data=eval("("+data+")");
        if(data.type == "comin"){
            // Room.black = data.targetid;
            Login.black=data.targetid;
            Login.room.blackname=data.message;
            play.connect(data.targetid);
            $("#black_user_name").text(data.message);
            addtext(data.message+"进入了房间!");
            addtext("等待黑方准备游戏...");
            $("#tyroPlay").val("等待黑方准备...");
            return;
        }
        if(data.type == "comout"){
            // Room.black = data.targetid;
            if(data.x==1){// 红方退出房间
                $("#red_user_name").text("无");
            }else{// 黑方退出房间
                $("#black_user_name").text("无");
            }
            play.isPlay=false;
            addtext(data.message+"退出了房间!");
            $("#tyroPlay").val("等待对手进入房间...");
            addtext("等待对手进入房间...");
            $("#tyroPlay").attr("disabled","false");
            return;
        }
        if(data.type == "gamestart"){
            if(Login.gamerole=="red"){
                $("#tyroPlay").val("开始游戏");
                $("#tyroPlay").removeAttr("disabled");
                addtext("黑方准备了,您可以开始游戏了!");
            }else{
                addtext("开始游戏了!");
                // $("#tyroPlay").attr("disabled","false");
                play.isPlay=true;
                play.init();
            }
            return;
        }
        if(data.type == "message"){
            addtext(data.message);
            return;
        }
        console.info("data"+data);
        var key=data.key;
        var oldx=data.oldx;
        var oldy=data.oldy;
        var x=data.x;
        var y=data.y;
        play.blackmove(key,oldx,oldy,x,y);
    };

    //连接关闭的回调方法
    websocket.onclose = (event)=>{

    };
}

//监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
window.onbeforeunload = ()=>{
    //$("#tx").append("连接关闭!");
    websocket.close();
};

//将消息显示在网页上
function setMessageInnerHTML(innerHTML){
    
};

//关闭连接
function closeWebSocket(){
    $("#tx").append("连接关闭!");
    websocket.close();
};

//发送消息
AppContext.send = (message)=>{
    //var message = document.getElementById('text').value;
    //var msg=$("#txt").val();
    var msg=JSON.stringify(message);
    // console.info("本地发送信息:"+msg);
    websocket.send(msg);
};