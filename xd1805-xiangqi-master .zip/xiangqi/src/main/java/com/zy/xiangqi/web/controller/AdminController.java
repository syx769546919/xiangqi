package com.zy.xiangqi.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
// import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.zy.xiangqi.entity.Room;
import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.entity.UserPacking;
import com.zy.xiangqi.exception.LoginException;
import com.zy.xiangqi.service.ActivitysService;
import com.zy.xiangqi.service.NewsService;
import com.zy.xiangqi.service.UserService;
import com.zy.xiangqi.utils.AppContext;

import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
// @ComponentScan(basePackages = { "com.zy.xiangqi.service" })
@RequestMapping("/admin")
@Slf4j
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private ActivitysService as;

    @Autowired
    private NewsService ns;

    @RequestMapping("/init")
    public String init(){
        return "redirect:login.html";
    }

    @RequestMapping("/login")
    public void login(User user,HttpServletRequest request,HttpServletResponse response,HttpSession session) throws ServletException, IOException{
        UserPacking login=userService.login(user);
        log.info("管理员登录: "+login.toString());
        AppContext.online.put(login.getUser().getId(), login);
        if(login==null||!"admin".equals(login.getUser().getRoles())){
            throw new LoginException("登录失败,用户名密码错误或权限不足!");
        }
        session.setAttribute("login",login);
        request.getRequestDispatcher("index.html").forward(request, response);
        //return "forward:index.html";
    }

    @RequestMapping("/quit")
    public String quit(HttpSession session){
        UserPacking up=(UserPacking)session.getAttribute("login");
        AppContext.online.remove(up.getUser().getId());//删除用户
        session.removeAttribute("login");
        return "redirect:login.html";
    }

    @RequestMapping("/allactive")
    public String allactive(){
        return "allactive";
    }

    @RequestMapping("/allnews")
    public String allnews(){
        return "allnews";
    }

    @RequestMapping("/main")
    public String main(HttpServletRequest request){
        request.setAttribute("usercount",userService.getCount());// 总注册数量
        request.setAttribute("useron",AppContext.online.size());// 当前在线人数
        request.setAttribute("activecount", as.getCount());// 数量
        request.setAttribute("newscount",ns.getCount());
        request.setAttribute("newslist",ns.findAll());
        request.setAttribute("activityslist",as.findAll());
        return "main";
    }

    @RequestMapping("/updatenews")
    public String updatenews(){
        return "updatenews";
    }

    // @PostMapping("/login")
    // public String login(User user, HttpSession session) {
    //     UserPacking login = userService.login(user);
    //     session.setAttribute("loginUser", login);
    //     return "home";
    // }

    @RequestMapping("/info")// 查看个人信息
    public String info(){
        return "info";
    }

    @RequestMapping("/updinfo")//修改个人信息
    public String updinfo(User user){
        return "";
    }

    @RequestMapping("/npwd")
    public String npwd(String old,String news,HttpSession session){
        return "";
    }
}