package com.zy.xiangqi.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 活动
 * 
 * @author ZhangYan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Activitys {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // 表明这个主键是自增的
	private Integer id;
	private Date startdate;// 活动开始日期
	private Date stopdate;// 活动结束日期
	private String title;// 活动名称
	private String content;// 活动简介
	private String types;// 类型
	// private String imgpath;// 活动图片
}
