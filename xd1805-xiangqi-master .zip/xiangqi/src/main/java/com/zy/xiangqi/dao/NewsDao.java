package com.zy.xiangqi.dao;

import java.util.List;

import com.zy.xiangqi.entity.News;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NewsDao extends JpaRepository<News, Integer> {
    public List<News> findByTitleLike(String title);
}