package com.zy.xiangqi.service.impl;

import java.util.List;

import com.zy.xiangqi.dao.PropDao;
import com.zy.xiangqi.entity.Prop;
import com.zy.xiangqi.service.PropService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PropServiceImpl implements PropService {
    @Autowired
    private PropDao propDao;

    @Override
    public List<Prop> findAll(){
        List<Prop> list=propDao.findAll();
        return list;
    }
}