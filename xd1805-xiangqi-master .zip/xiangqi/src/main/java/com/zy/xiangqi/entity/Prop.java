package com.zy.xiangqi.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 道具接口
 * 
 * @author ZhangYan
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Prop {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;// 道具ID
	private String name;// 道具名称
	private String types;// 道具分类
	private Integer price;// 道具价格
	private String content;// 商品描述
}
