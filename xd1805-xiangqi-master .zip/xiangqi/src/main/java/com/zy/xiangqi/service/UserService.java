package com.zy.xiangqi.service;

import java.util.List;

import com.zy.xiangqi.entity.Prop;
import com.zy.xiangqi.entity.Records;
import com.zy.xiangqi.entity.Room;
import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.entity.UserPacking;
import com.zy.xiangqi.exception.LoginException;
import com.zy.xiangqi.exception.RegisterException;

public interface UserService {
    // 登录
    public UserPacking login(User user) throws LoginException;

    // 注册
    public void register(User user) throws RegisterException;

    // 验证用户名是否已被占用
    public Boolean checkName(String name) throws Exception;

    // 更新游戏状态
    public Boolean updStatus(UserPacking user,String status) throws Exception;

    // 修改密码
    public Boolean updPwd(UserPacking user,String old, String pwd) throws Exception;

    // 赠送礼物
    // public Boolean give(UserPacking from, Integer to, Prop gift) throws Exception;

    // 添加好友
    public Boolean addFriend(UserPacking self, Integer friendId) throws Exception;

    // 删除好友
    public Boolean delFriend(UserPacking self, Integer friendId) throws Exception;

    // 查找所有历史对战记录
    public List<Records> findAllRecords(UserPacking user) throws Exception;

    // 增加一条对战记录
    public Boolean addRecords(Room room,Records records) throws Exception;

    // 购买商品
    public Boolean buyProp(UserPacking user, Prop prop) throws Exception;

    // 使用商品
    public Boolean useProp(UserPacking user, Prop prop) throws Exception;

	public List<User> findAll();

    public Long getCount();
    public User finduserbyid(int id);

	public void updateuser(User user);
}