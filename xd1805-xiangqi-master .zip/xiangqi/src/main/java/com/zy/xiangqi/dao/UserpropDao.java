package com.zy.xiangqi.dao;

import com.zy.xiangqi.entity.Userprop;
import com.zy.xiangqi.entity.UserpropMultiKeys;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserpropDao extends JpaRepository<Userprop, UserpropMultiKeys> {
    // public Userprop findByUseridAndPropid(Integer userid,Integer propid);
}