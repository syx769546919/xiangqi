package com.zy.xiangqi.service;

import java.util.List;
import com.zy.xiangqi.entity.News;

public interface NewsService {
    public List<News> findByTitle(String title);
    public Boolean addNews(News news);
	public List<News> findAll();
	public News findById(Integer id);
	public void remove(Integer id);
	public Long getCount();
	public void save(News news);
}