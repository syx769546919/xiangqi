package com.zy.xiangqi.exception;

public class RegisterException extends RuntimeException {
    public RegisterException(String msg){
        super(msg);
    }
}