package com.zy.xiangqi.dao;

import java.util.List;

import com.zy.xiangqi.entity.Friendslist;
import com.zy.xiangqi.entity.FriendslistMultiKeys;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FriendslistDao extends JpaRepository<Friendslist, FriendslistMultiKeys> {
    @Query(value="select * from friendslist where selfid = ?1 or targetid= ?1",nativeQuery=true)
    public List<Friendslist> findBySelfidOrTargetid(Integer id);

    @Query(value="select * from friendslist where selfid = ?1 and targetid= ?2 or selfid = ?2 and targetid = ?1",nativeQuery=true)
    public Friendslist findBySelfidAndTargetid(Integer selfid,Integer targetid);
}