package com.zy.xiangqi.entity;

public enum Status {
	ONLINE,//在线
	OFFLINE,//离线
	BUSY,//忙碌
	GAMING,//游戏中
	OB,//观战中
	INVISIBLE//隐身
}
