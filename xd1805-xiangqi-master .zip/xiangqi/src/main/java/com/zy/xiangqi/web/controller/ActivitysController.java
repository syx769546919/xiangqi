package com.zy.xiangqi.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.zy.xiangqi.entity.Activitys;
import com.zy.xiangqi.service.ActivitysService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/activitys")
@Slf4j
public class ActivitysController {

    @Autowired
    private ActivitysService as;

    @RequestMapping("/findAllActivitys")
    public String findAllActivitys(HttpServletRequest request){
        log.info("findAllActivitys...");
        List<Activitys> list=as.findAll();
        request.setAttribute("activityslist",list);
        return "allactive";
    }

    @RequestMapping("/upd/{id}")
    public void upd(@PathVariable("id") Integer id){
    }
}