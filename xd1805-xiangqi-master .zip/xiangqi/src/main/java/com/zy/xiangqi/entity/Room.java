package com.zy.xiangqi.entity;

import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Room {
	private Integer id;// id
	private String name;// 房间名
	private Integer master;// 房主
	private Integer red;// 红色方
	private Integer black;// 黑色方
	private String redname;
	private String blackname;
	private Set<UserPacking> watch;// 观战
	private Checkerboard checkerboard;// 棋盘类
	private String status;// 房间状态
	private Integer count=0;

	public void addCount(){
		count++;
	}
}
