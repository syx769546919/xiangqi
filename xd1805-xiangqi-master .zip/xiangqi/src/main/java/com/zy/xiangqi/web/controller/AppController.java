package com.zy.xiangqi.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppController {
    @GetMapping("/login")
    public String login(){
        return "forward:login.html";
    }
    @GetMapping("/register")
    public String register(){
        return "forward:register.html";
    }
    @GetMapping("/ai")
    public String ai(){
        return "forward:ai.html";
    }
}