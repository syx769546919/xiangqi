package com.zy.xiangqi.entity;

import lombok.Data;

@Data
public class MessageContext {// 信息中心
    private String message;
    private String type;
    private String key;
    private Integer x;
    private Integer y;
    private Integer oldx;
    private Integer oldy;
    private Integer targetid;
    // private String name;
}