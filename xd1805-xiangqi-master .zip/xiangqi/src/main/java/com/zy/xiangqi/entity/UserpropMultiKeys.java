package com.zy.xiangqi.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserpropMultiKeys implements Serializable {
    private static final long serialVersionUID = 4857690045714348379L;
    private Integer userid;
    private Integer propid;
}