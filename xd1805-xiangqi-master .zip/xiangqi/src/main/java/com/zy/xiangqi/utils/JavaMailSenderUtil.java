package com.zy.xiangqi.utils;

import java.io.File;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JavaMailSenderUtil {

    @Autowired
    private static JavaMailSender mailSender;

    public static Boolean simpleSender(String from,String to,String subject,String text){
        // 纯文本格式发送邮件
        SimpleMailMessage message = new SimpleMailMessage();
        try{
            message.setFrom(from);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            mailSender.send(message);
            log.info("邮件发送成功! 信息: from:"+from+"; to:"+to+"; subject:"+subject);
        } catch (Exception e){
            log.error("邮件发送失败! 信息: from:"+from+"; to:"+to+"; subject:"+subject+"; text:"+text);
            return false;
        }
        return true;
    }
    
    public static Boolean senderHtmlMail(String from,String to,String subject,String text){
        // 发送HTML 格式邮件
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper=null;
        try {
            // true表示需要创建一个multipart message
            helper = new MimeMessageHelper(mimeMessage, true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(text); // 其中: <img src='cid:文件识别码'/> 与下面的addInline对应 可在页面显示图片
            // helper.setCc(cc);// 抄送人
            // helper.setBcc(bcc);// 密送人

            // File file=new File(filePath); //资源信息必须放在setText()之后
            // helper.addAttachment("文件名称.txt",file);
            // helper.addInline("文件识别码",file);
            mailSender.send(mimeMessage);// 发送邮件
        } catch (MessagingException e) {
            log.error("邮件发送失败! 信息: from:"+from+"; to:"+to+"; subject:"+subject+"; text:"+text);
            return false;
        }
        return true;
    }

    public void sendAttachmentsMail(String from,String to, String subject, String content, String filePath){
		MimeMessage message = mailSender.createMimeMessage();
 
		try {
			//true表示需要创建一个multipart message
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(content, true);
 
			FileSystemResource file = new FileSystemResource(new File(filePath));
			String fileName = filePath.substring(filePath.lastIndexOf(File.separator));
	        helper.addAttachment(fileName, file);
	        
			mailSender.send(message);
			log.info("带附件的邮件已经发送。");
		} catch (MessagingException e) {
			log.error("发送带附件的邮件时发生异常！", e);
		}
	}
}