package com.zy.xiangqi.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
// import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
// import javax.websocket.server.PathParam;

// import com.alibaba.fastjson.JSON;
import com.zy.xiangqi.entity.MessageContext;
import com.zy.xiangqi.entity.Room;
import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.entity.UserPacking;
import com.zy.xiangqi.service.NewsService;
import com.zy.xiangqi.service.UserService;
import com.zy.xiangqi.utils.AppContext;
import com.zy.xiangqi.utils.WebSocketUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
// import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Controller
// @ComponentScan(basePackages = { "com.zy.xiangqi.service" })
@RequestMapping("/user")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private NewsService ns;

    @RequestMapping("/login")
    public String login(User user, HttpSession session) {
        UserPacking login = userService.login(user);
        AppContext.online.put(login.getUser().getId(), login);
        session.setAttribute("login", login);
        session.setAttribute("roomlist",AppContext.rooms);
        session.setAttribute("newslist",ns.findAll());
        session.setAttribute("alluseron", AppContext.online.size());
        return "gamehall";
    }

    @RequestMapping("/quit")
    public String quit(HttpSession session){
        UserPacking up=(UserPacking)session.getAttribute("login");
        AppContext.online.remove(up.getUser().getId());//删除用户
        session.removeAttribute("login");

        return "redirect:/login.html";
    }

    @RequestMapping("/register")
    public String register(User user,HttpSession session) {
        userService.register(user);
        return "redirect:/login.html";
    }

    @RequestMapping("/findall")
    public String findall(HttpServletRequest request){
        List<User> list=userService.findAll();
        request.setAttribute("userlist", list);
        return "alluser";
    }

    @RequestMapping("/activation/{current}/{id}")// 用户通过邮箱链接激活账号界面
    public String activation(@PathVariable("current") Long current,@PathVariable("id") Integer id){
        return "";
    }

    @RequestMapping("/info")// 查看个人信息
    public String info(){
        return "personalinf";
    }

    @RequestMapping("/updateinfo")//修改个人信息
    public String updinfo(String opwd,User user,HttpSession session){
        UserPacking up=(UserPacking)session.getAttribute("login");
        if(!up.getUser().getPwd().equals(opwd)){
            throw new RuntimeException("原始密码错误!");
        }
        //System.out.println(up);
        int id=up.getUser().getId();
        //System.out.println(id);
        User olduser=userService.finduserbyid(id);
        //System.out.println(olduser);
        olduser.setPwd(user.getPwd());
        olduser.setEmail(user.getEmail());
        olduser.setImgpath(user.getImgpath());
        //System.out.println(user);
        userService.updateuser(olduser);
        return "gamehall";
    }

    @RequestMapping("/npwd")
    public @ResponseBody String npwd(String old,String news,HttpSession session){
        try {
            userService.updPwd((UserPacking) session.getAttribute("login"), old, news);
        } catch (Exception e) {
            //e.printStackTrace();
            return "修改失败!";
        }
        return "修改成功!";
    }
    // /user/room/{id} 进入房间
    // /user/backromm 出房间
    @RequestMapping("/buy/{propid}")// 购买商品
    public String buy(@PathVariable("propid") Integer propid,HttpSession session){
        return "";
    }

    @RequestMapping("/use/{propid}")// 使用商品
    public String use(@PathVariable("propid") Integer propid,HttpSession session){
        return "";
    }

    @RequestMapping("/addroom")// 添加房间
    public String addroom(String name,HttpSession session){
        Room room=new Room();
        room.setName(name);
        UserPacking up=(UserPacking)session.getAttribute("login");
        // log.info("session:"+up.toString());
        up.setGamerole("red");
        int id=up.getUser().getId();
        id+=name.hashCode();
        room.setId(id);
        room.setRed(up.getUser().getId());
        room.setRedname(up.getUser().getName());
        room.addCount();
        room.setStatus("休息中");
        up.setRoom(room);
        session.setAttribute("login",up);
        AppContext.rooms.add(room);
        return "redirect:/gameRoom.html";
    }

    @RequestMapping("/room/{id}") // 进入房间
    public String room(@PathVariable("id") Integer id,HttpSession session){
        log.info("进入房间ID:"+id);
        UserPacking up=(UserPacking)session.getAttribute("login");
        if(up==null) throw new RuntimeException("用户未登录");
        up.setGamerole("black");
        Room room=AppContext.getRoom(id);
        if(room==null) throw new RuntimeException("房间信息错误");
        room.setBlack(up.getUser().getId());
        room.setBlackname(up.getUser().getName());
        room.addCount();
        room.setStatus("已满");
        Integer rid=room.getRed();
        MessageContext msg=new MessageContext();
        // msg.setType("connect");
        // msg.setTargetid(up.getUser().getId());
        // String upmsg=JSON.toJSONString(up);
        // msg.setMessage(upmsg);
        // WebSocketUtil.sendMessage(rid, msg);
        up.setRoom(room);
        session.setAttribute("login",up);
        // MessageContext m=new MessageContext();
        // m.setType("message");
        // m.setMessage(up.getUser().getName()+"进入了房间!");
        // WebSocketUtil.sendMessage(rid,m);
        msg.setType("comin");
        msg.setTargetid(up.getUser().getId());
        msg.setMessage(up.getUser().getName());
        WebSocketUtil.sendMessage(rid, msg);
        log.info("进入房间成功!");
        return "redirect:/gameRoom.html";
    }

    @RequestMapping("/json")
    public @ResponseBody UserPacking json(HttpSession session){
        return (UserPacking)session.getAttribute("login");
    }

    // @RequestMapping("/getRoom")
    // public @ResponseBody Room getRoom(HttpSession session){
    //     return ((UserPacking)session.getAttribute("login")).getRoom();
    // }
}