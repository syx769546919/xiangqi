package com.zy.xiangqi.service;

import java.util.List;

import com.zy.xiangqi.entity.Activitys;

public interface ActivitysService {
    public List<Activitys> findAll();

	public Long getCount();
}