package com.zy.xiangqi.dao;

import com.zy.xiangqi.entity.User;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserDao extends JpaRepository<User, Integer> {
    // 登录
    public User findByNameAndPwd(String name, String pwd);

    // 验证用户名是否存在
    public User findByName(String name);
}