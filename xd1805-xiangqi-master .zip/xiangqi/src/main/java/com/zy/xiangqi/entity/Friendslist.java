package com.zy.xiangqi.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@IdClass(FriendslistMultiKeys.class)
public class Friendslist {

    @Id
    private Integer selfid;// 好友请求发起者
    @Id
    private Integer targetid;// 接受者
    @JSONField(format="yyyy-MM-dd: HH:mm:ss")
    private Date friendship;// 成为好友的时间
    private Boolean enable;// 是否激活

    public Integer getTargetid(Integer id){
        return selfid==id?targetid:selfid;
    }
}