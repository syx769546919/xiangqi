package com.zy.xiangqi.web.websocket;

import java.io.IOException;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.alibaba.fastjson.JSON;
import com.zy.xiangqi.entity.MessageContext;
import com.zy.xiangqi.entity.Room;
import com.zy.xiangqi.entity.UserPacking;
import com.zy.xiangqi.utils.AppContext;
import com.zy.xiangqi.utils.WebSocketUtil;

import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.PathVariable;

import lombok.extern.slf4j.Slf4j;

@Component
@ServerEndpoint("/websocket/{id}")
@Slf4j
public class WebSocketController {
    @OnOpen
    public void OnOpen(@PathParam("id") Integer id,Session session){// 有人连接时调用
        log.info(id+"连接");
        // UserPacking up=AppContext.findByUserid(id);//获取到用户
        // if(up==null) return;
        // String message=id+"进入了游戏";//up.getUser().getName()+"进入了游戏";
        // WebSocketUtil.sendMessageForAll(message);
        WebSocketUtil.addSession(id, session);
        // UserPacking up=AppContext.online.get(id);

        //if(up==null) throw new RuntimeException("登录信息错误");


    }
    @OnMessage
    public void onMessage(@PathParam("id") Integer id,String message){// 发送了新消息
        // UserPacking up=AppContext.findByUserid(id);//获取到用户
        // if(up==null) return;
        // 将接收信息转为Message对象
        // MessageContext mc=(MessageContext)JSON.parseObject(message, MessageContext.class);
        // String msg=id+"说: "+message;// up.getUser().getName()+" 说:"+message;
        MessageContext msg=(MessageContext)JSON.parseObject(message, MessageContext.class);
        log.info("onMessage to:"+id+" "+msg.toString());
        //WebSocketUtil.sendMessageForAll(msg);
        if("message".equals(msg.getType())||"news".equals(msg.getType())){
            WebSocketUtil.sendMessageForAll(message);
            return;
        }
        WebSocketUtil.sendMessage(msg.getTargetid(), message);
    }
    @OnError
    public void onError(@PathParam("id") Integer id,Session session,Throwable throwable){// 出现异常
        log.error("出现错误,错误信息:"+throwable.getMessage());
        WebSocketUtil.removeAndCloseSession(id);
        throwable.printStackTrace();
    }
    @OnClose
    public void onClose(@PathParam("id") Integer id,Session session){
        log.info(id+"退出");
        // String message=id+"退出";
        WebSocketUtil.removeAndCloseSession(id);
        UserPacking up=AppContext.online.get(id);
        if(up==null) return;
        Room room=up.getRoom();
        if(room!=null){
            if(up.getGamerole().equals("red")){
                room.setRed(null);
            }else if(up.getGamerole().equals("black")){
                room.setBlack(null);
            }
            up.setGamerole(null);
            up.setRoom(null);
            if(room.getRed()==null&&room.getBlack()==null){
                AppContext.rooms.remove(room);
            }else{
                if(room.getRed()!=null){
                    room.setCount(room.getCount()-1);
                    //给红方发送退出房间信息
                    MessageContext mc=new MessageContext();
                    mc.setType("comout");
                    mc.setMessage(up.getUser().getName());
                    mc.setX(-1);
                    WebSocketUtil.sendMessage(room.getRed(),mc);
                }
                if(room.getBlack()!=null){
                    room.setCount(room.getCount()-1);
                    MessageContext mc=new MessageContext();
                    mc.setType("comout");
                    mc.setMessage(up.getUser().getName());
                    mc.setX(1);
                    WebSocketUtil.sendMessage(room.getBlack(),mc);
                }
            }
        }
        // WebSocketUtil.sendMessageForAll(message);
    }
}