package com.zy.xiangqi.service.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.zy.xiangqi.dao.FriendslistDao;
import com.zy.xiangqi.dao.RecordsDao;
import com.zy.xiangqi.dao.UserDao;
import com.zy.xiangqi.dao.UserpropDao;
import com.zy.xiangqi.entity.Friendslist;
import com.zy.xiangqi.entity.Prop;
import com.zy.xiangqi.entity.Records;
import com.zy.xiangqi.entity.Room;
import com.zy.xiangqi.entity.Status;
import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.entity.UserPacking;
import com.zy.xiangqi.entity.Userprop;
import com.zy.xiangqi.entity.UserpropMultiKeys;
import com.zy.xiangqi.exception.LoginException;
import com.zy.xiangqi.exception.RegisterException;
import com.zy.xiangqi.service.UserService;
import com.zy.xiangqi.utils.AppContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao ud;
    @Autowired
    private UserpropDao upd;
    @Autowired
    private FriendslistDao fd;
    @Autowired
    private RecordsDao rd;

    @Override// 登录
    public UserPacking login(User user) throws LoginException {
        User luser = ud.findByNameAndPwd(user.getName(),user.getPwd());
        if(luser==null){
            throw new LoginException("用户名或密码错误!");
        }
        // if(!luser.getActivity()){
        //     throw new LoginException("您的账号还未邮箱验证,请您进入邮箱验证!");
        // }
        // Integer id=luser.getId();// 获取用户id
        UserPacking lup=new UserPacking(luser); // 获取用户包装类
        log.info(lup.toString());
        // if(luser.getRoles().equals("admin")){ // 管理员不需要补充其他信息
        //     AppContext.addOnline(lup);
        //     return lup;
        // }
        // List<Friendslist> list=fd.findBySelfidOrTargetid(id); // 同步好友列表
        // Set<User> friends=new HashSet<User>();// 好友列表
        // Set<User> req = new HashSet<User>();// 好友请求
        // if(list!=null){
        //     for (Friendslist fri : list) {
        //         Integer tid=fri.getTargetid(id);
        //         User t=ud.findById(tid).get();
        //         if(fri.getEnable()){
        //             friends.add(t);
        //         }else{
        //             req.add(t);// 好友请求列表添加
        //         }
        //     }
        // }
        // lup.setFriends(friends);
        // lup.setReq(req);
        AppContext.addOnline(lup); // 将登陆用户添加至在线用户列表
        return lup;
    }

    @Override// 注册
    public void register(User user) throws RegisterException {
        if(user==null){
            throw new RegisterException("注册数据错误!");
        }
        if(user.getName()==null||user.getName().equals("")){
            throw new RegisterException("用户名错误!");
        }
        User temp=ud.findByName(user.getName());
        if(temp!=null){
            throw new RegisterException("用户名已存在,请换个用户名!");
        }
        user.setActivity(false);// 设置为邮箱未激活
        user.setStatu("正常");
        user.setAge(18);
        user.setCoin(100);
        user.setCharm(100);
        user.setCountmoney(0);
        user.setCreatetime(new java.sql.Date(System.currentTimeMillis()));
        user.setGamecount(0);
        user.setHeight(1);
        user.setLevels(1);
        user.setWin(0);
        user.setLevelsize(1);
        user.setRoles("user");
        user=ud.save(user);
        // 生成激活链接
        // long current=System.currentTimeMillis();
        // String url="http:localhost:8080/activation/"+current+"/"+user.getId();
        // String message="欢迎注册在线网络象棋! 您的激活链接为:"+url;
        //发送邮件
    }

    @Override// 验证用户名是否存在
    public Boolean checkName(String name) throws Exception {
        User user = ud.findByName(name);
        return user == null;
    }

    public User finduserbyid(int id){
        return ud.findById(id).get();
    }
    @Override// 更新游戏状态
    public Boolean updStatus(UserPacking user,String status) throws Exception {
        user.setStatus(Status.valueOf(status));
        return null;
    }

    @Override// 更新密码
    public Boolean updPwd(UserPacking user,String old, String pwd) throws Exception {
        if(!user.getUser().getPwd().equals(old)){
            throw new RuntimeException("旧密码错误!");
        }
        user.getUser().setPwd(pwd);
        ud.save(user.getUser());
        return true;
    }

    // @Override// 赠送礼物
    // public Boolean give(UserPacking from, Integer to, Prop gift) throws Exception {
    //     return null;
    // }

    @Override // 添加好友
    public Boolean addFriend(UserPacking self, Integer friendId) throws Exception {
        if(self==null||self.getUser()==null||friendId==null) return false;
        //暂不考虑是否已经是好友
        Friendslist fl=new Friendslist();
        fl.setSelfid(self.getUser().getId());
        fl.setTargetid(friendId);
        fl.setEnable(false);
        fl.setFriendship(new Date(System.currentTimeMillis()));
        // 发送好友申请
        //判断是否在线 在线 则通过webSocket发送好友请求 同时更新对方好友请求列表
        return true;
    }

    @Override // 删除好友
    public Boolean delFriend(UserPacking self, Integer friendId) throws Exception {
        Friendslist fl=fd.findBySelfidAndTargetid(self.getUser().getId(),friendId);
        fd.delete(fl);
        // 通知被删除好友
        // 更新双方好友列表
        // 返回结果
        return true;
    }

    @Override // 查找所有游戏记录
    public List<Records> findAllRecords(UserPacking user) throws Exception {
        return null;
    }

    @Override // 添加一条游戏记录
    public Boolean addRecords(Room room,Records records) throws Exception {
        // 添加记录到数据库
        records=rd.save(records);
        // 更新双方用户的经验和金币
        // UserPacking uw=records.getWin().equals("red")?room.getRed():room.getBlack();
        // UserPacking ul=records.getWin().equals("black")?room.getBlack():room.getRed();
        // uw.getUser().addCoin(records.getWincoin());
        // ul.getUser().addCoin(records.getLowcoin());
        // uw.getUser().addLevelsize(records.getWinlevs());
        // ul.getUser().addLevelsize(records.getLowlevs());
        // // 更新用户记录
        // uw.addRecords(records);
        // ul.addRecords(records);
        // // 更新双方对局信息  对局数 剩数 败数
        // uw.getUser().addGamecount();

        return null;
    }

    @Override // 购买商品
    public Boolean buyProp(UserPacking user, Prop prop) throws Exception {
        Integer coin = user.getUser().getCoin();//用户金币
        Integer price = prop.getPrice();
        Integer userid = user.getUser().getId();
        Integer propid = prop.getId();
        if(price>coin) return false;
        user.getUser().setCoin(coin-price);// 更新用户金币
        //Userprop up=upd.findByUseridAndPropid(userid,propid);
        UserpropMultiKeys umk=new UserpropMultiKeys(userid,propid);
        Userprop up=upd.findById(umk).get();
        if(up==null){
            up = new Userprop();
            up.setUserid(userid);
            up.setPropid(propid);
            up.setHave(1);
        }else{
            up.setHave(up.getHave()+1);
        }
        up=upd.save(up);//保存到数据库
        // 更新用户道具
        user.updUP(up);
        return true;
    }

	@Override // 使用道具
	public Boolean useProp(UserPacking user, Prop prop) throws Exception {
		return null;
	}

    @Override
    public List<User> findAll() {
        return ud.findAll();
    }

    @Override
    public Long getCount() {
        return ud.count();
    }

    @Override
    public void updateuser(User user) {
        ud.deleteById(user.getId());
        ud.save(user);
    }

}