package com.zy.xiangqi;

// import com.zy.xiangqi.config.XiangQiConfiguration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import lombok.extern.slf4j.Slf4j;
// import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
// @EnableConfigurationProperties(XiangQiConfiguration.class)
//@Slf4j
public class XiangqiApplication {

	public static void main(String[] args) {
		SpringApplication.run(XiangqiApplication.class, args);
	}

}