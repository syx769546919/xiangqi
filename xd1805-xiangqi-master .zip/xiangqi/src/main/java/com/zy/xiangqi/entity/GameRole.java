package com.zy.xiangqi.entity;

public enum GameRole {
	RED,BLACK,OB
}
