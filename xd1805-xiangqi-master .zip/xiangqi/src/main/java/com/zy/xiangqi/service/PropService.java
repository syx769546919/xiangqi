package com.zy.xiangqi.service;

import java.util.List;

import com.zy.xiangqi.entity.Prop;

// import com.zy.xiangqi.dao.PropDao;

// import org.springframework.beans.factory.annotation.Autowired;

public interface PropService {
    public List<Prop> findAll();
}