package com.zy.xiangqi.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zy.xiangqi.entity.Activitys;
// import com.zy.xiangqi.config.XiangQiConfiguration;
import com.zy.xiangqi.entity.News;
import com.zy.xiangqi.entity.Room;
import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.entity.UserPacking;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * 应用中心
 * 
 * @author ZhangYan
 *
 */
@Getter
@Setter
public final class AppContext {
	public static Date starttiem = new Date();;// 服务器启动时间
	public static Map<Integer,UserPacking> online=new HashMap<Integer,UserPacking>();// 所有在线用户
	public static List<Room> rooms=new ArrayList<Room>();// 所有房间列表

	public static List<Activitys> activitys=new ArrayList<>();// 当前活动
	public static List<News> news=new ArrayList<>();// 新闻/公告

	public static List<User> level=new ArrayList<>();// 等级排行榜
	public static List<User> height=new ArrayList<>();// 段位排行榜
	public static List<User> charm=new ArrayList<>();// 魅力排行榜

	public static Set<String> allowpath=new HashSet<String>();

	// @Autowired
	// private static XiangQiConfiguration xqconfig;

	// 添加用户
    public static void addOnline(UserPacking user){
		Integer id=user.getUser().getId();
		online.put(id,user);// 添加在线用户
		// 向其它客户端发送用户登录信息
		WebSocketUtil.sendMessageForAll("{'type':'login','context':"+id+"}");//发送json信息
	}

	// 验证用户在线记录
	// public static Boolean checkOnline(Integer id){
	// 	return online.containsKey(id);
	// }

	public static UserPacking findByUserid(Integer id){
		return online.get(id);
	}

	public static Set<String> getAllowpath(){
		if(allowpath.size()>5){
			return allowpath;
		}
		allowpath.add("/login");
		allowpath.add("/login.html");
		allowpath.add("/register");
		allowpath.add("/register.html");
		allowpath.add("/ai");
		allowpath.add("/ai.html");
		allowpath.add("error");
		allowpath.add("404.html");
		allowpath.add("init");
		allowpath.add(".png");
		allowpath.add(".jpg");
		allowpath.add(".js");
		allowpath.add(".css");
		allowpath.add(".mp3");
		allowpath.add(".gif");
		allowpath.add(".json");
		allowpath.add(".ico");
		allowpath.add(".eot");
		allowpath.add(".svg");
		allowpath.add(".ttf");
		allowpath.add(".woff");
		allowpath.add(".woff2");
		return allowpath;
	}

	public static Room getRoom(int id) {
		for (Room room : rooms) {
			if(room.getId()==id||room.getId().equals(id)) return room;
		}
		return null;
	}
}
