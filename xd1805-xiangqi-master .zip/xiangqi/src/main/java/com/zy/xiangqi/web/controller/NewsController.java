package com.zy.xiangqi.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;

import com.zy.xiangqi.entity.MessageContext;
import com.zy.xiangqi.entity.News;
import com.zy.xiangqi.service.NewsService;
import com.zy.xiangqi.utils.WebSocketUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/news")
@Slf4j
public class NewsController {

    @Autowired
    private NewsService newsService;

    // @RequestMapping("/{title}")
    // public String login(@PathVariable("title") String title, HttpServletRequest request) {
    //     // List<News> list = newsService.findByTitle(title);
    //     // request.setAttribute("list", list);
    //     return "test";
    // }

    @RequestMapping("/add")
    public String add(News news){
        log.info("NewsController: "+news.toString());
        newsService.addNews(news);
        MessageContext message=new MessageContext();
        message.setType("message");
        String msg="系统公告: 标题:"+news.getTitle()+" <br/>公告内容:"+news.getContent();
        message.setMessage(msg);
        WebSocketUtil.sendMessageForAll(message);
        return "redirect:/admin/newsAdd.html";
    }

    @RequestMapping("/findall")
    public ModelAndView findall(){
        List<News> list=newsService.findAll();
        ModelAndView mav=new ModelAndView();
        mav.addObject("newslist", list);
        mav.setViewName("usernews");
        return mav;
    }
    @RequestMapping("/adminfindall")
    public ModelAndView adminfindall(){
        List<News> list=newsService.findAll();
        ModelAndView mav=new ModelAndView();
        mav.addObject("newslist", list);
        mav.setViewName("allnews");
        return mav;
    }

    @RequestMapping("/upd/{id}")
    public ModelAndView upd(@PathVariable("id")Integer id){
        System.out.println(id);
        News news=newsService.findById(id);
        System.out.println(news);
        ModelAndView mav=new ModelAndView();
        mav.addObject("news", news);
        mav.setViewName("updatenews");
        return mav;
    }

    @RequestMapping("/updatenews")
    public String update(News news){
        //System.out.println(news);
        newsService.save(news);
        return "redirect:/news/adminfindall";
    }
    @ResponseBody
    @RequestMapping("/del")
    public String del(int newsId){
        System.out.print(newsId);
        newsService.remove(newsId);
        return newsId+"";
    }

    @RequestMapping("/opennews")
    public String opennews(Integer newsid,HttpServletRequest request){
        System.out.print(newsid);
        News news=newsService.findById(newsid);
        request.setAttribute("news",news);
        return "news";
    }

    @RequestMapping("/search")
    public ModelAndView search(String key){
        String keys="%"+key+"%";
        List<News> list=newsService.findByTitle(keys);
        log.info(list.toString());
        log.info("查询大小:"+list.size());
        ModelAndView mav=new ModelAndView();
        mav.addObject("newslist", list);
        mav.setViewName("allnews");
        return mav;
    }

}