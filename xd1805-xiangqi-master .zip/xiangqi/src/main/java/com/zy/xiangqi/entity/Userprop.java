package com.zy.xiangqi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
// import javax.persistence.JoinColumn;
// import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@IdClass(UserpropMultiKeys.class)
public class Userprop {

    @Id
    // @ManyToOne
    // @JoinColumn(name = "userid") // 维护外键 表明外键设置在我这一方
    private Integer userid;// 用户id
    @Id
    // @ManyToOne
    // @JoinColumn(name = "propid") // 维护外键 表明外键设置在我这一方
    private Integer propid;//

    private Integer have;// 数量
}