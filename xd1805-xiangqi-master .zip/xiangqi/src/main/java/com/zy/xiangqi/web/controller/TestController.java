package com.zy.xiangqi.web.controller;

import java.util.List;

import com.zy.xiangqi.dao.FriendslistDao;
import com.zy.xiangqi.dao.RecordsDao;
import com.zy.xiangqi.dao.UserpropDao;
import com.zy.xiangqi.entity.Friendslist;
import com.zy.xiangqi.entity.Prop;
import com.zy.xiangqi.entity.Records;
import com.zy.xiangqi.entity.User;
import com.zy.xiangqi.entity.Userprop;
import com.zy.xiangqi.service.PropService;
import com.zy.xiangqi.service.UserService;
// import com.zy.xiangqi.service.impl.RoleServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    private UserService userService;
    @Autowired
    private RecordsDao rd;
    // @Autowired
    // private RoleServiceImpl rser;
    @Autowired
    private PropService propService;
    @Autowired
    private UserpropDao userProp;
    @Autowired
    private FriendslistDao fd;

    @GetMapping("/byid/{id}")
    public User byid(@PathVariable("id") Integer id){
        User t=new User();
        t.setName("admin");
        t.setPwd("123456");
        User user=null;
        try {
            // user=userService.login(t);
        } catch (Exception e) {
        }
        return t;
    }
    
    @GetMapping("/findbyrec")
    public Records findbyuser(){
        Records records=rd.findById(1).get();
        return records;
    }

    // @GetMapping("/role")
    // public Role role(){
    //     // Role role=rser.findById(1);
    //     // System.out.println(role);
    //     // return role;
    // }

    @RequestMapping("/props")
    public List<Prop> findAll(){
        return propService.findAll();
    }

    @RequestMapping("/uprop")
    public List<Userprop> uprop(){
        return userProp.findAll();
    }

    @RequestMapping("/friend")
    public List<Friendslist> friend(){
        return fd.findAll();
    }
}