package com.zy.xiangqi.service.impl;

import java.util.List;

import com.zy.xiangqi.dao.ActivitysDao;
import com.zy.xiangqi.entity.Activitys;
import com.zy.xiangqi.service.ActivitysService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ActivitysServiceImpl implements ActivitysService {

    @Autowired
    private ActivitysDao ad;

    @Override
	public List<Activitys> findAll() {
		return ad.findAll();
	}

    @Override
    public Long getCount() {
        return ad.count();
    }

}