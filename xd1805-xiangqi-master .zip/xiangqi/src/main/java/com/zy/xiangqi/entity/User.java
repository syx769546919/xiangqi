package com.zy.xiangqi.entity;

import java.sql.Date;
// import java.util.List;
// import java.util.Set;

// import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
// import javax.persistence.JoinColumn;
// import javax.persistence.JoinTable;
// import javax.persistence.ManyToMany;
// import javax.persistence.ManyToOne;
// import javax.persistence.OneToMany;
// import javax.validation.constraints.Email;
import com.alibaba.fastjson.annotation.JSONField;
import javax.validation.constraints.Size;
//import org.hibernate.validator.constraints.Length;

// import org.springframework.data.annotation.Transient;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;// id
    @Size(min=2,max=12,message="用户名长度必须在2-12之间")
    private String name;// 昵称
    @Size(min=6,max=16,message="密码长度必须在6-16之间")
    private String pwd;// 密码
    private Integer sex;// 性别
    private Integer age;// 年龄
    private String imgpath;// 头像路径
    private Integer levels;// 等级
    private Integer levelsize;// 经验
    private Integer height;// 段位
    private String roles;// 角色
    private Boolean activity;// 该账号邮箱是否已被验证/激活
    private String statu;// 用户状态 冻结/正常
    @JSONField(format="yyyy-MM-dd: HH:mm:ss")//使用json生式
    private Date createtime;// 创建账户日期
    // @Email(message="邮箱格式错误")
    private String email;// 邮箱
    private Integer charm;// 魅力值
    private Integer coin;// 金币
    private Integer money;// 点券
    private Integer countmoney;// 总充值
    private String city;// 所在城市
    private Integer gamecount;// 游戏总场次
    private Integer win;// 获胜场次
    private Integer los;// 失败场次

    public void addCoin(int coin){
        this.coin += coin;
    }

    public void addMoney(int money){
        this.money += money;
    }

    public void addCharm(int charm){
        this.charm += charm;
    }

    public void addCountmoney(int money){
        countmoney+=money;
    }

    public void addGamecount(){
        gamecount++;
    }

    public void addWin(){
        win++;
    }

    public void addLos(){
        los++;
    }

    public void addLevelsize(int levelsize){
        this.levelsize+=levelsize;
    }
}
