/* package com.zy.xiangqi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@ConfigurationProperties(prefix="xiangqi.settings")
@Component
public class XiangQiConfiguration {
    private Boolean enableEmail;// 邮件激活
} */