package com.zy.xiangqi.exception;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class CommonExceptionHandler {// 统一异常处理
    @ExceptionHandler(Exception.class)
    // @ResponseBody
    public ModelAndView exceptionHandler(HttpServletRequest request,Exception e){
        ModelAndView mav=new ModelAndView();
        mav.addObject("exception", e.getMessage());
        mav.addObject("url",request.getRequestURL().toString());
        mav.setViewName("error");
        return mav;
    }

    @ExceptionHandler(LoginException.class)
    public ModelAndView loginExceptionHandler(HttpServletRequest request,Exception e){
        ModelAndView mav=new ModelAndView();
        mav.addObject("exception", "登录异常: "+e.getMessage());
        mav.addObject("url",request.getRequestURL().toString());
        mav.setViewName("error");
        return mav;
    }
}