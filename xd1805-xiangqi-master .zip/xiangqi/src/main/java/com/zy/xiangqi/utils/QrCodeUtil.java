package com.zy.xiangqi.utils;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.swetake.util.Qrcode;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class QrCodeUtil {
    /**
	 * 生成二维码
	 * @author 张闫
	 * @param content 生成二维码的内容
	 * @throws Exception 
	 * */
	public static BufferedImage getQrCode(String content){//,String c
		int width=235;
		int height=235;
		
		Qrcode qrcode=new Qrcode();
		//设置二维码的排错率  L(7%) M(15%) Q(25%) H(30%)
		qrcode.setQrcodeErrorCorrect('M');
		//设置二进制
		qrcode.setQrcodeEncodeMode('B');
		//设置版本号
		qrcode.setQrcodeVersion(15);
		
		//参数分别是宽度高度和图像的类型
		BufferedImage img=new BufferedImage(width,height,BufferedImage.TYPE_INT_BGR);
		//画笔
		Graphics2D grap=img.createGraphics();
		//设置背景色为白色
		grap.setBackground(Color.WHITE);
		//清空内容 创建二维码的矩形区域
		grap.clearRect(0, 0, width, height);
		//画笔颜色为黑色
		grap.setColor(Color.BLACK);
		
		try {
			//将传进来的content字符串转为byte数组
			byte[] cont=content.getBytes("utf-8");
			//将字节型数组转为布尔型二维数组
			boolean[][] codeOut =qrcode.calQrcode(cont);
			
			//绘制二维码
			int z=2;
			for(int i=0;i<codeOut.length;i++){
				for(int j=0;j<codeOut.length;j++){
					if(codeOut[i][j]){
						grap.fillRect(j*3+z, i*3+z, 3, 3);
					}
				}
			}
			
			//释放资源
			grap.dispose();
			img.flush();
			
			//生成二维码
			//File imgFile=new File("../images/qrcode.png");
			//ImageIO.write(img, "jpg", response.getOutputStream());
			return img;
		} catch (Exception e) {
			log.error("生成二维码失败! ");
		}finally{
			if(grap!=null){
				grap.dispose();
			}else if(img!=null){
				img.flush();
			}
        }
        return null;
	}
}