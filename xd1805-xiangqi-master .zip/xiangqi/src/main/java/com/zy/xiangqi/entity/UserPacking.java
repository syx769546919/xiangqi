package com.zy.xiangqi.entity;

import java.util.Set;

// import java.util.List;
// import java.util.Map;
import lombok.Data;
import lombok.EqualsAndHashCode;
// import lombok.NoArgsConstructor;

/**
 * User的包装类
 * 
 * @author ZhangYan
 *
 */

@Data
@EqualsAndHashCode(callSuper = false)
public final class UserPacking {

	private User user;

	// 外键
    // @ManyToOne
    // @JoinColumn(name = "roles") // 维护外键 表明外键设置在我这一方
    // @OneToMany(cascade = CascadeType.REMOVE) // 设置为级联删除
    private Set<Records> records;// 对战记录
    // @ManyToMany(cascade = CascadeType.REMOVE) // 设置为级联删除
    // @JoinTable(name = "friendslist", // name:指定中间表名
    //         joinColumns = @JoinColumn(referencedColumnName = "selfid"), // joinColumns: 指定中间表中与自己关联的字段名
    //         inverseJoinColumns = @JoinColumn(name = "targetid")) // inverseJoinColumns: 指定另一侧
    private Set<User> friends;// 好友列表
    private Set<User> req;// 好友请求列表
    // @ManyToMany
	private Set<Userprop> props;// 拥有的道具及其数量
	
	// 无关
	private Status status;// 当前游戏状态
	private Room room;// 当前所属房间
	private String gamerole;// 游戏中所属阵营

	public UserPacking(User user) {
		this.user = user;
    }
    
    // 判断用户道具列表中是否有对应记录
    public void updUP(Userprop up){
        if(props==null) return;
        for (Userprop upi : props) {
            if(up.getPropid()==up.getPropid()){
                props.remove(upi);
                break;
            }
        }
        props.add(up);
    }

    // 添加一条对局记录
    public boolean addRecords(Records record){
        return records.add(record);
    }
}
