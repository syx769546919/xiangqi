package com.zy.xiangqi.service.impl;

import java.util.List;

import com.zy.xiangqi.dao.NewsDao;
import com.zy.xiangqi.entity.News;
import com.zy.xiangqi.service.NewsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NewsServiceImpl implements NewsService {

    @Autowired
    private NewsDao newsDao;

    public List<News> findByTitle(String title) {
        return newsDao.findByTitleLike(title);
    }

    @Override
    public Boolean addNews(News news) {
        news=newsDao.save(news);
        log.info("NewsService: "+news.toString());
        return true;
    }

    @Override
    public List<News> findAll() {
        return newsDao.findAll();
    }

    @Override
    public News findById(Integer id) {
        return newsDao.findById(id).get();
    }

    @Override
    public void remove(Integer id) {
        newsDao.deleteById(id);;
    }

    @Override
    public Long getCount() {
        return newsDao.count();
    }

    @Override
    public void save(News news) {
        newsDao.save(news);
    }
}