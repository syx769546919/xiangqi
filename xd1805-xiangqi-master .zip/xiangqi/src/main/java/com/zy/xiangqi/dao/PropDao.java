package com.zy.xiangqi.dao;

import com.zy.xiangqi.entity.Prop;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PropDao extends JpaRepository<Prop, Integer> {
}