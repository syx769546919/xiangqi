package com.zy.xiangqi.exception;

public class LoginException extends RuntimeException {// 自定义登录异常
    public LoginException(String msg){
        super(msg);
    }
}