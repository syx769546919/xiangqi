package com.zy.xiangqi.web.interceptor;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zy.xiangqi.entity.UserPacking;
import com.zy.xiangqi.utils.AppContext;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LoginInterceptor implements HandlerInterceptor {

    // 在控制器执行前调用 用于拦截用户是否登录
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // log.info("Login拦截器执行!");
        String uri=request.getRequestURI();
        if(uri.equals("/")){
            log.info("Login拦截器: 拦截路径:"+uri);
            response.sendRedirect("/login");
            return false;
        }
        UserPacking user=(UserPacking)request.getSession().getAttribute("login");
        if(user!=null){
            log.info("Login拦截器: user释放路径:"+uri);
            return true;
        }
        
        // if(uri.endsWith("login")||uri.endsWith("register")||uri.endsWith("ai")||uri.endsWith("error")){
        //     log.info("Login拦截器: with释放路径:"+uri);
        //     return true;
        // }

        Set<String> set=AppContext.getAllowpath();
        for (String path : set) {
            if(uri.endsWith(path)){
                log.info("Login拦截器: with释放路径:"+uri);
                return true;
            }
        }

        log.info("Login拦截器: 拦截路径:"+uri);
        response.sendRedirect("/login");
        return false;
    }

    // 在后端执行器执行后调用
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
        throws Exception {
    }

    // 整个请求执行完后调用
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
    }

}