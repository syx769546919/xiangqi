package com.zy.xiangqi.utils;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.Session;
import javax.websocket.RemoteEndpoint.Async;

import com.alibaba.fastjson.JSON;
import com.zy.xiangqi.entity.MessageContext;
import com.zy.xiangqi.exception.LoginException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WebSocketUtil {
    // 所有在线列表
    private static final Map<Integer,Session> ONLINE_SESSION = new ConcurrentHashMap<>();
    public static void addSession(Integer key,Session session){
        if(key==null||session==null) return;
        // if(AppContext.checkOnline(key)){
        //     throw new LoginException("用户在线认证失败,请重新登录!");
        // }
        log.info(key+": 已添加至在线列表");
        if(ONLINE_SESSION.containsKey(key)){
            // key已存在 覆盖
        }else{
            ONLINE_SESSION.put(key, session);
        }
    }
    // public static void removeSession(Integer key){
    //     if(key==null) return;
    //     ONLINE_SESSION.remove(key);
    // }
    public static void removeAndCloseSession(Integer key){
        if(key==null) return;
        log.info(key+": 从在线列表移除");
        // try{
        //     Session session=ONLINE_SESSION.get(key);
        //     if(session!=null) session.close();
        // }catch(IOException e){
        //     e.printStackTrace();
        // }finally{
            ONLINE_SESSION.remove(key);
        // }
    }
    // public static void removeAndCloseSession(Session session){
    //     if(session==null) return;
    //     try{
    //         session.close();
    //     }catch(IOException e){
    //         e.printStackTrace();
    //     }finally{
            
    //     }
    // }
    // 向某一用户发送信息
    public static void sendMessage(Integer key,String message){
        if(key==null) return;
        if(!ONLINE_SESSION.containsKey(key)) return;//这里应该抛异常
        // getAsyncRemote()和getBasicRemote() 异步与同步
        Async async=ONLINE_SESSION.get(key).getAsyncRemote();
        log.info("sendMessage: to:"+key+" "+message);
        async.sendText(message);
    }
    // 向某一用户发送信息 重载
    public static void sendMessage(Session session,String message){
        if(session==null) return;
        // getAsyncRemote()和getBasicRemote() 异步与同步
        Async async=session.getAsyncRemote();
        async.sendText(message);
    }
    // 向某一用户发送信息
    public static void sendMessage(Integer key,MessageContext message){
        if(key==null) return;
        if(!ONLINE_SESSION.containsKey(key)) return;//这里应该抛异常
        // getAsyncRemote()和getBasicRemote() 异步与同步
        Async async=ONLINE_SESSION.get(key).getAsyncRemote();
        String msg=JSON.toJSONString(message);
        log.info("sendMessage: to:"+key+" "+msg);
        async.sendText(msg);
    }
    // 向某一用户发送信息 重载
    public static void sendMessage(Session session,MessageContext message){
        if(session==null) return;
        // getAsyncRemote()和getBasicRemote() 异步与同步
        Async async=session.getAsyncRemote();
        String msg=JSON.toJSONString(message);
        async.sendText(msg);
    }
    // 向所有人发送消息
    public static void sendMessageForAll(String message){
        ONLINE_SESSION.forEach((sessionId,session)->sendMessage(session,message));
    }
     // 向所有人发送消息
     public static void sendMessageForAll(MessageContext message){
        ONLINE_SESSION.forEach((sessionId,session)->sendMessage(session,message));
    }

    // 服务器停机 向所有人发送停机信息
    public static void shutdown() throws IOException {
        for (Entry<Integer,Session> entry : ONLINE_SESSION.entrySet()) {
            Session se=entry.getValue();
            MessageContext msg=new MessageContext();
            msg.setType("message");
            msg.setMessage("服务器关闭,您已断开连接!");
            sendMessage(se,msg);
            se.close();
        }
    }
}