package com.zy.xiangqi.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.ManyToOne;

import com.alibaba.fastjson.annotation.JSONField;

//import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 对战记录
 * 
 * @author ZhangYan
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Records {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    // @ManyToOne
    // @JsonBackReference // 如果要转为json 为了防止无限调用 要在多的一方使用这个注解 这个注解要写在set方法上
    private Integer redid;// 红色方id
    // @ManyToOne
    // @JsonBackReference
    private Integer blackid;// 黑色方Id
    private String win;// 赢的一方
    @JSONField(format="yyyy-MM-dd: HH:mm:ss")
    private Date starttime;// 开始时间
    private Integer ctime;// 持续时间
    private Integer counts;// 游戏回合数
    private Integer wincoin;// 胜方金币
    private Integer winlevs;// 胜方经验
    private Integer lowcoin;// 败方金币
    private Integer lowlevs;// 败方经验
}
