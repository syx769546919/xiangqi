package com.zy.xiangqi.web.interceptor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zy.xiangqi.entity.UserPacking;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.slf4j.Slf4j;

// 权限拦截器 拦截验证管理员,
@Component
@Slf4j
public class AdminInterceptor implements HandlerInterceptor {

    // 在控制器执行前调用
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        UserPacking up=(UserPacking)request.getSession().getAttribute("login");
        String uri=request.getRequestURI();
        if(uri.endsWith("/login")||uri.endsWith("/init")||uri.endsWith("login.html")){
            log.info("Admin拦截器: with释放路径:"+uri);
            return true;
        }
        if(up==null){
            log.info("Admin拦截器: null拦截路径:"+uri);
            return false;
        }
        log.info(up.getUser().getName()+" - "+up.getUser().getRoles());
        if("admin".equals(up.getUser().getRoles())){
            log.info("Admin拦截器: admin释放路径:"+uri);
            return true;
        }
        response.sendRedirect("/admin/init");
        log.info("Admin拦截器: 拦截路径:"+uri);
        return false;
    }

    // 在后端执行器执行后调用
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
        throws Exception {
    }

    // 整个请求执行完后调用
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
    }
    
}