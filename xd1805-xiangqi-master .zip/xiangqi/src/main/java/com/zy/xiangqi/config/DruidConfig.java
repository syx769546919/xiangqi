package com.zy.xiangqi.config;

import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="spring.datasource")
public class DruidConfig {
    @Bean
    public ServletRegistrationBean druidServlet(){
        ServletRegistrationBean srb=new ServletRegistrationBean(new StatViewServlet(),"/druid/*");
        srb.addInitParameter("allow", "127.0.0.1");
        srb.addInitParameter("loginUsername", "admin");// 设置登录查看信息的用户名
        srb.addInitParameter("loginPassword","123456");// 设置登录查看信息的密码
        srb.addInitParameter("resetEnable", "false");// 是否能够重置数据
        return srb;
    }
    @Bean
    public FilterRegistrationBean druidStatFilter(){
        FilterRegistrationBean frb=new FilterRegistrationBean(new WebStatFilter());
        frb.addUrlPatterns("/*");// 添加过滤规则
        frb.addInitParameter("exclusions", "*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*");// 添加不需要忽略的格式信息 
        return frb;
    }
}